package com.adcb.ocr.engine.tess;

public interface TextReader {
	
	String readText(String filePath) throws Exception;

}
